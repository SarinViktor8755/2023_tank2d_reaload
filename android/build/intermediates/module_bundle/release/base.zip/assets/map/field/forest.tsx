<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="forest" tilewidth="32" tileheight="32" spacing="1" margin="1" tilecount="342" columns="18">
 <tileoffset x="1" y="1"/>
 <image source="forest.png" width="626" height="659"/>
</tileset>
